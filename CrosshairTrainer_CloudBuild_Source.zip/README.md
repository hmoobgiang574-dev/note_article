# Crosshair Trainer — Cloud Build

Dự án mẫu Android để tạo APK qua GitHub Actions từ điện thoại. Ứng dụng chỉ hiển thị dấu tâm nổi có thể kéo; không tự động ngắm/bắn và không can thiệp bộ nhớ game.

## Tạo APK chỉ bằng điện thoại
1. Tạo tài khoản GitHub tại https://github.com/signup.
2. Trên trình duyệt, tạo repository mới, đặt tên `CrosshairTrainer`, chọn **Public** (dễ thiết lập nhất cho người mới) và tạo repository.
3. Tải ZIP này về, giải nén bằng ứng dụng quản lý tệp trên điện thoại.
4. Mở repository trên GitHub trong Chrome, bật **Trang web cho máy tính** từ menu ⋮.
5. Chọn **Add file → Upload files**, tải lên toàn bộ nội dung đã giải nén, gồm cả thư mục `.github` (thư mục ẩn). Nếu trình duyệt không cho tải thư mục, dùng công cụ GitHub upload hoặc chuyển sang AndroidIDE.
6. Nhấn **Commit changes**. Workflow sẽ tự chạy khi đẩy lên nhánh `main`.
7. Mở tab **Actions → Build Android APK**. Chọn lần chạy thành công → phần **Artifacts** → tải `CrosshairTrainer-debug-apk`.
8. Giải nén tệp artifact tải về; bên trong có `app-debug.apk`. Mở APK để cài và nếu được hỏi, cho phép Chrome/Files cài ứng dụng từ nguồn này.

## Lưu ý
- GitHub Actions cần kết nối Internet và có thể mất vài phút ở lần build đầu.
- Nếu giao diện điện thoại không tải lên được cả thư mục `.github`, quy trình này sẽ không tự chạy. Không chia sẻ mật khẩu hoặc personal access token với người lạ.
- APK debug chưa được phát hành/kiểm thử chính thức. Android hoặc Free Fire có thể chặn overlay.
