package com.example.crosshairtrainer;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 4001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 32, 28, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(22, 25, 30));

        TextView title = new TextView(this);
        title.setText("Crosshair Trainer");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView desc = new TextView(this);
        desc.setText("Tâm ngắm nổi để luyện căn tâm. Không tự động ngắm, bắn hoặc can thiệp vào game.");
        desc.setTextColor(Color.LTGRAY);
        desc.setTextSize(16);
        desc.setPadding(0, 18, 0, 24);
        root.addView(desc);

        Button start = new Button(this);
        start.setText("Cấp quyền & bật tâm");
        root.addView(start, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_OVERLAY);
            } else {
                startOverlay();
            }
        });

        Button stop = new Button(this);
        stop.setText("Tắt tâm ngắm");
        root.addView(stop, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        stop.setOnClickListener(v -> stopService(new Intent(this, CrosshairService.class)));

        TextView note = new TextView(this);
        note.setText("Cách dùng: bật tâm, chuyển sang ứng dụng/game. Kéo biểu tượng nhỏ để đổi vị trí. Nếu game không cho hiển thị overlay, hãy dùng ứng dụng luyện tập riêng.");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(14);
        note.setPadding(0, 24, 0, 0);
        root.addView(note);

        setContentView(root);
    }

    private void startOverlay() {
        try {
            startService(new Intent(this, CrosshairService.class));
            Toast.makeText(this, "Đã bật tâm ngắm", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Không thể bật overlay: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY && Settings.canDrawOverlays(this)) {
            startOverlay();
        }
    }
}
