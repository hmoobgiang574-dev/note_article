package com.example.crosshairtrainer;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class CrosshairService extends Service {
    private WindowManager windowManager;
    private TextView crosshair;
    private WindowManager.LayoutParams params;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        crosshair = new TextView(this);
        crosshair.setText("＋");
        crosshair.setTextColor(Color.RED);
        crosshair.setTextSize(34);
        crosshair.setTypeface(Typeface.DEFAULT_BOLD);
        crosshair.setGravity(Gravity.CENTER);
        crosshair.setShadowLayer(4f, 0f, 0f, Color.BLACK);
        crosshair.setContentDescription("Tâm ngắm có thể kéo để di chuyển");

        int overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 300;
        params.y = 500;

        crosshair.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float touchX, touchY;

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        touchX = event.getRawX();
                        touchY = event.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + (int) (event.getRawX() - touchX);
                        params.y = initialY + (int) (event.getRawY() - touchY);
                        try {
                            windowManager.updateViewLayout(crosshair, params);
                        } catch (IllegalArgumentException ignored) { }
                        return true;
                    default:
                        return false;
                }
            }
        });

        windowManager.addView(crosshair, params);
    }

    @Override
    public void onDestroy() {
        if (crosshair != null && windowManager != null) {
            try { windowManager.removeView(crosshair); } catch (Exception ignored) { }
            crosshair = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
